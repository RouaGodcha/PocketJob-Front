import { Component } from '@angular/core';

@Component({
  selector: 'app-home-register',
  standalone: false,
  templateUrl: './home-register.component.html',
  styleUrl: './home-register.component.scss'
})
export class HomeRegisterComponent {

}
