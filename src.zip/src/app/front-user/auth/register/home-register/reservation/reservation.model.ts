export interface ReservationMission {
    nomMission: string;
    dateDebut: string; // ISO format: yyyy-mm-dd
    dateFin: string;
    emplacement: string;
    horaires: string;
  }
  