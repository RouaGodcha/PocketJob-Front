export interface News {
    entreprise: string;
    titre: string;
    dateDebut: string;
    dateFin: string;
    lieu: string;
    message: string;
    datePublication: string;
    avatars: string[];
    is_read?: boolean;
  }
  