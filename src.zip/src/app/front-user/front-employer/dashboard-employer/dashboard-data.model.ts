export interface DashboardData {
    employerAddress: string;
    employerName: string;
    offresActives: number;
    candidaturesRecues: number;
    entretiensAvenir: number;
    messagesNonLus: number;
    notifications: string[];
  }
  