import { Component } from '@angular/core';

@Component({
  selector: 'app-employer-layout',
  standalone: false,
  templateUrl: './employer-layout.component.html',
  styleUrl: './employer-layout.component.scss'
})
export class EmployerLayoutComponent {

}
