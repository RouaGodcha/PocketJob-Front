import { Component } from '@angular/core';

@Component({
  selector: 'app-fiches',
  standalone: false,
  templateUrl: './fiches.component.html',
  styleUrl: './fiches.component.scss'
})
export class FichesComponent {

}
