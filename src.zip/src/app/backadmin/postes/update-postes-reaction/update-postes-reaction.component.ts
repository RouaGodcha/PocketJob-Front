import { Component } from '@angular/core';

@Component({
  selector: 'app-update-postes-reaction',
  standalone: false,
  templateUrl: './update-postes-reaction.component.html',
  styleUrl: './update-postes-reaction.component.scss'
})
export class UpdatePostesReactionComponent {

}
